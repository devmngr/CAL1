#pragma once
node_t * read_students();				//read students from file and add them to a list
/*void read_teachers(void *);				//read teachers from file and add them to a list
void read_courses(void *);				//read courses from file and add them to a list
void read_student_enrollments(void *);	//read students enrollments from file and add them to a list
void read_teacher_assignments(void *);	//read teacher assignments from file and add them to a list


void write_students(void *);				// write from a list of students to a file 
void write_teachers(void *);				// write from a list of teacherd to a file 
void write_courses(void *);					// write from a list of courses to a file 
void write_student_enrollments(void *);		// write from a list of student enrollments to a file 
void write_teacher_assignments(void *);		// write from a list of teacher assignments to a file */